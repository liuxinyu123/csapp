#include <stdio.h>
#include "isa.h"
#include "pipeline.h"
#include "stages.h"
#include "sim.h"

/* The following is a default function for pipelines without 
   single cycle pople implementations.
   By putting this in a separate file, it will get linked and used only if
   there is no definition for a signal new_fd_icode in the HCL.
*/

int gen_new_fd_icode()
{
    return if_id_next->icode;
}
