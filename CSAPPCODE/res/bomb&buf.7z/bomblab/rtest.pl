#!/usr/bin/perl 
#!/usr/local/bin/perl 
use Getopt::Std;

#######################################################################
# rtest - Bomb regression test
#
# Copyright (c) 2002, R. Bryant and D. O'Hallaron, All rights reserved.
# May not be used, modified, or copied without permission.
#
# This program makes and test <n> random bombs

# Usage: rtest [-h] -n <num>";
# Options:";
#   -h           Print this message.";
#   -n <num>     Number of bombs to make and test
#
######################################################################

$| = 1; # autoflush output on every print statement

#
# usage - print help message and terminate
#
sub usage 
{
    printf STDERR "Usage: $0 [-h] -n <num>\n";
    printf STDERR "Options:\n";
    printf STDERR "  -h           Print this message.\n";
    printf STDERR "  -n <num>     Number of bombs to make and test.\n";
    die "\n";
}

##############
# Main routine
##############

# 
# Parse and check the command line arguments
#
getopts('hn:');
if (($opt_h) or (!$opt_n) or ($opt_n < 1)) {
    usage();
}

# 
# Now make and test a bunch of random non-notifying bombs 
#
for ($i=1; $i <= $opt_n; $i++) {
    print ".";
    system("make cleanall  > /dev/null 2>&1");
    system("./makephases.pl -d phases -l test -i $i > phases.c") == 0
	or die "\n$0: ERROR: makephases for bomb $i failed\n";
    system("make bomb > /dev/null 2>&1") == 0
	or die "\n$0: ERROR: 'make bomb' for bomb $i failed\n";
    system("make bomb-solve > /dev/null 2>&1") == 0
	or die "\n$0: ERROR: 'make bomb-solve' for bomb $i failed\n";
    system("make check-bomb > /dev/null 2>&1") == 0
	or die "\n$0: ERROR: Bomb $i exploded\n";
}	
print "\n$opt_n bombs checked out OK.\n";
exit;
