/* 
 * phase4a.c - A recursive function to sort out.  
 * Computes the fibonnaci number of its input, must match the fibonacci
 * number randomly generated. 
 */
#if defined(PROBLEM)
int func4(int i) {
    if (i <= 1) {
	return 1;
    }

    return func4(i - 1) + func4(i - 2);
}
#elif defined(SOLUTION)
/* Given Fibonacci number y=F(x) return x */
int func4_inverse(int y) 
{
    switch (y) {
    case 55 : return 9; 
    case 89 : return 10; 
    case 144 : return 11; 
    case 233 : return 12; 
    case 377 : return 13; 
    case 610 : return 14; 
    case 987 : return 15;
    case 1597 : return 16; 
    case 2584 : return 17; 
    case 4181 : return 18; 
    case 6765 : return 19; 
    case 10946 : return 20; 
    case 17711 : return 21; 
    case 28657 : return 22; 
    case 46368 : return 23;
    default:
	printf("ERROR: bad input in phase4a\n");
	exit(8);
    }
}
#endif

void phase_4(char *input) {
#if defined(PROBLEM)
    int result, val, numScanned = sscanf(input, "%d", &val);

    if ((numScanned != 1) || (val < 1)) {
	explode_bomb();
    }

    result = func4(val);

    if (result != FIB_NUMBER_SET) {
	explode_bomb();
    }
#elif defined(SOLUTION)
    printf("%d %s\n", func4_inverse(FIB_NUMBER_GET), SECRET_PHRASE);
#else
    invalid_phase("4a");
#endif
}

