/*
 * phase5b.c - This stage requires the user to enter 6 numbers that are used
 * as offsets into the character array.  The six characters indexed
 * by the offsets must spell out a particular word.                   
 */
void phase_5(char *input)
{
#if defined(PROBLEM)
    static char array[] = {
	'i',
	's',
	'r',
	'v',
	'e',
	'a',
	'w',
	'h',
	'o',
	'b',
	'p',
	'n',
	'u',
	't',
	'f',
	'g'
    };

    int i, length;
    char theWord[7];

    length = string_length(input);
    if (length != 6)
	explode_bomb();
    
    for (i = 0; i < 6; i++)
	theWord[i] = array[ (input[i] & 0x0f) ];
    theWord[6] = '\0';

    /* ravens, giants, titans, saints */
    if (strings_not_equal(theWord, "SHORT_WORD_SET") != 0)
	explode_bomb();
#elif defined(SOLUTION)
    if (!strcmp("SHORT_WORD_GET", "ravens"))
	printf("2534;1\n");
    else if (!strcmp("SHORT_WORD_GET", "giants"))
	printf("?05;=1\n");
    else if (!strcmp("SHORT_WORD_GET", "titans"))
	printf("=0=5;1\n");
    else if (!strcmp("SHORT_WORD_GET", "saints"))
	printf("150;=1\n");
    else {
	printf("ERROR: bad short_word in phase 5b\n");
	exit(8);
    }
#else
invalid_phase("5b");
#endif
}

