/* 
 * phase4c.c - A recursive function to sort out.  
 * Computes the factorial number of their input, must match the factorial
 * number randomly generated. 
*/
#if defined(PROBLEM)
int func4(int i) {
    if (i <= 1) {
	return 1;
    }
    return i * func4(i - 1);
}
#elif defined(SOLUTION)
/* given y=x!, return x */
int func4_inverse(int y) {
    switch (y) {
    case 24: return 4;
    case 120: return 5;
    case 720: return 6;
    case 5040: return 7;
    case 40320: return 8;
    case 362880: return 9;
    case 3628800: return 10;
    default:
	fprintf(stderr, "ERROR: bad input in phase4c\n");
	exit(8);
    }
}
#endif

void phase_4(char *input) {
#if defined(PROBLEM)
    int result, val, numScanned = sscanf(input, "%d", &val);

    if((numScanned != 1) || (val < 1)) {
	explode_bomb();
    }

    result = func4(val);

    if(result != FACTORIAL_SET) {
	explode_bomb();
    }
#elif defined(SOLUTION)
    printf("%d %s\n", func4_inverse(FACTORIAL_GET), SECRET_PHRASE);
#else
    invalid_phase("4c");
#endif
}
