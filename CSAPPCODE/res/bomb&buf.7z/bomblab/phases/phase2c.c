/* 
 * phase2c.c - To defeat this stage the user must enter sequence of 
 * 6 numbers such that x[i] = x[i+3], not all zero.
 */
void phase_2(char *input)
{
#if defined(PROBLEM)
    int ii, sum = 0;
    int numbers[6];

    read_six_numbers(input, numbers);

    for (ii = 0; ii < 3; ii++) {
	if (numbers[ii] != numbers[ii+3])
	    explode_bomb();
	sum += numbers[ii];
    }

    if (sum == 0)
	explode_bomb();
#elif defined(SOLUTION)
    printf("1 2 3 1 2 3\n");
#else
    invalid_phase("2c");
#endif
}

